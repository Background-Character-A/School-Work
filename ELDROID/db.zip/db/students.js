require('dotenv').config();
const express = require('express');
const sqlite = require("sqlite3").verbose();
const path = require('path');
const router = express.Router();

const table = 'students';

const databaseFile = process.env.DATABASE || './db/school.db';
const database = path.isAbsolute(databaseFile)
  ? databaseFile
  : path.resolve(__dirname, '..', databaseFile);
let conn = null;

function connect() {
  conn = new sqlite.Database(database, sqlite.OPEN_READWRITE | sqlite.OPEN_CREATE, (err) => {
    if (err) {
      console.error('SQLite open error:', err.message);
    }
  });
}
function close() {
	if (conn != null) {
		conn.close((err) => {
			if (err) console.log("Error closing database");
		});
	}
}

// GET all students
router.get("/", (req, res) => {
	let sql = "SELECT * FROM `" + table + "`";
	connect();
	conn.all(sql, (err, rows) => {
		close();
		if (err) return res.status(500).json(err);
		return res.status(200).json(rows);
	});
});

// GET single student by id
router.get("/:id", (req, res) => {
	const id = req.params.id;
	const sql = "SELECT * FROM `" + table + "` WHERE `id`=?";
	connect();
	conn.get(sql, [id], (err, row) => {
		close();
		if (err) return res.status(500).json(err);
		return res.status(200).json(row || null);
	});
});

// DELETE student by id
router.delete("/:id", (req, res) => {
	let idno = req.params.id;
	let sql = "DELETE FROM `" + table + "` WHERE `id`=?";
	connect();
	conn.run(sql, [idno], (err) => {
		close();
		if (err) return res.status(500).json(err);
		return res.status(200).json({ 'message': 'Student Deleted' });
	});
});

// POST new student
router.post("/", (req, res) => {
	let data = req.body;
	let keys = Object.keys(data);
	let values = Object.values(data);

	let fld = keys.join("`,`");

	let qmark = [];
	keys.forEach((key) => { qmark.push('?'); }); // FIX: was keys.foreach (lowercase)
	let q = qmark.join(",");

	let sql = "INSERT INTO `" + table + "`(`" + fld + "`) VALUES (" + q + ")"; // FIX: was VALUES (q) not VALUES (${q})
	console.log(sql);
	connect();
	conn.run(sql, values, (err) => {
		close();
		if (err) return res.status(500).json(err);
		return res.status(200).json({ 'message': 'New Student Added' });
	});
});

// PUT update student
router.put("/", (req, res) => {
	const { id, ...updates } = req.body;
	if (!id) {
		return res.status(400).json({ error: 'Missing student id' });
	}

	const keys = Object.keys(updates);
	const values = Object.values(updates);
	if (keys.length === 0) {
		return res.status(400).json({ error: 'No fields to update' });
	}

	const setClause = keys.map((key) => "`" + key + "`=?").join(',');
	const sql = "UPDATE `" + table + "` SET " + setClause + " WHERE `id`=?";
	connect();
	conn.run(sql, [...values, id], function (err) {
		close();
		if (err) return res.status(500).json(err);
		return res.status(200).json({ message: 'Student Updated', changes: this.changes });
	});
});

module.exports = router;