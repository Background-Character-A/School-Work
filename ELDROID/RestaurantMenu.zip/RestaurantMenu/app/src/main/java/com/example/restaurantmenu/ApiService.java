package com.example.restaurantmenu;

import android.os.Handler;
import android.os.Looper;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ApiService {

    private static final String BASE_URL = "http://192.168.254.150/chef_menu/customer_menu.html";
    // CHANGE THIS INTO THE COMPUTER IP ADDRESS
    private final ExecutorService executor;
    private final Handler mainHandler;
    private final Gson gson;

    public interface ApiCallback<T> {
        void onSuccess(T result);
        void onError(String error);
    }

    public ApiService() {
        executor = Executors.newSingleThreadExecutor();
        mainHandler = new Handler(Looper.getMainLooper());
        gson = new Gson();
    }

    public void getMeals(ApiCallback<List<Meal>> callback) {
        executor.execute(() -> {
            try {
                URL url = new URL( "http://192.168.254.150/chef_menu/get_meals.php");
                // CHANGE THIS INTO THE COMPUTER IP ADDRESS
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(10000);
                conn.setReadTimeout(10000);

                int responseCode = conn.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(
                            new InputStreamReader(conn.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String line;

                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    reader.close();

                    Type listType = new TypeToken<ArrayList<Meal>>(){}.getType();
                    List<Meal> meals = gson.fromJson(response.toString(), listType);

                    mainHandler.post(() -> callback.onSuccess(meals));
                } else {
                    mainHandler.post(() -> callback.onError("HTTP Error: " + responseCode));
                }
                conn.disconnect();

            } catch (Exception e) {
                mainHandler.post(() -> callback.onError(e.getMessage()));
            }
        });
    }
}