package com.example.restaurantmenu;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.util.ArrayList;
import java.util.List;

public class MealAdapter extends RecyclerView.Adapter<MealAdapter.MealViewHolder> {

    private List<Meal> meals;
    private OnMealClickListener listener;

    public interface OnMealClickListener {
        void onMealClick(Meal meal);
    }

    public MealAdapter(OnMealClickListener listener) {
        this.meals = new ArrayList<>();
        this.listener = listener;
    }

    public void setMeals(List<Meal> meals) {
        this.meals = meals;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public MealViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_meal, parent, false);
        return new MealViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MealViewHolder holder, int position) {
        Meal meal = meals.get(position);
        holder.bind(meal, listener);
    }

    @Override
    public int getItemCount() {
        return meals.size();
    }

    static class MealViewHolder extends RecyclerView.ViewHolder {
        ImageView mealImage;
        TextView mealName;
        TextView mealPrice;
        TextView mealDescription;
        TextView mealCategory;

        public MealViewHolder(@NonNull View itemView) {
            super(itemView);
            mealImage = itemView.findViewById(R.id.mealImage);
            mealName = itemView.findViewById(R.id.mealName);
            mealPrice = itemView.findViewById(R.id.mealPrice);
            mealDescription = itemView.findViewById(R.id.mealDescription);
            mealCategory = itemView.findViewById(R.id.mealCategory);
        }

        public void bind(Meal meal, OnMealClickListener listener) {
            mealName.setText(meal.getName());
            mealPrice.setText(String.format("$%.2f", meal.getPrice()));
            mealDescription.setText(meal.getDescription().isEmpty() ?
                    "No description available" : meal.getDescription());
            mealCategory.setText(meal.getCategory());

            if (meal.getImage() != null && !meal.getImage().isEmpty()) {
                Glide.with(itemView.getContext())
                        .load(meal.getImage())
                        .placeholder(R.color.placeholder)
                        .error(R.color.placeholder)
                        .into(mealImage);
            }

            itemView.setOnClickListener(v -> listener.onMealClick(meal));
        }
    }
}