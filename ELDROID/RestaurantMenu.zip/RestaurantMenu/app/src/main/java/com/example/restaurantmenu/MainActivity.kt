package com.example.restaurantmenu

import android.app.Dialog
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var mealAdapter: MealAdapter
    private lateinit var apiService: ApiService
    private lateinit var fabCart: FloatingActionButton

    private val allMeals = mutableListOf<Meal>()
    private val cart = mutableListOf<CartItem>()
    private var currentFilter = "all"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.recyclerView)
        fabCart = findViewById(R.id.fabCart)
        apiService = ApiService()

        setupRecyclerView()
        setupCategoryButtons()
        setupFabButton()
        loadMeals()
    }

    private fun setupRecyclerView() {
        mealAdapter = MealAdapter { meal -> addToCart(meal) }
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = mealAdapter
    }

    private fun setupCategoryButtons() {
        findViewById<Button>(R.id.btnAll).setOnClickListener { filterCategory("all") }
        findViewById<Button>(R.id.btnAppetizer).setOnClickListener { filterCategory("Appetizer") }
        findViewById<Button>(R.id.btnMainCourse).setOnClickListener { filterCategory("Main Course") }
        findViewById<Button>(R.id.btnDessert).setOnClickListener { filterCategory("Dessert") }
        findViewById<Button>(R.id.btnBeverage).setOnClickListener { filterCategory("Beverage") }
    }

    private fun setupFabButton() {
        fabCart.setOnClickListener { openCartDialog() }
    }

    private fun loadMeals() {
        apiService.getMeals(object : ApiService.ApiCallback<List<Meal>> {
            override fun onSuccess(result: List<Meal>) {
                allMeals.clear()
                allMeals.addAll(result)
                displayMeals()
            }

            override fun onError(error: String) {
                Toast.makeText(this@MainActivity, "Error: $error", Toast.LENGTH_LONG).show()
            }
        })
    }

    private fun filterCategory(category: String) {
        currentFilter = category
        displayMeals()
    }

    private fun displayMeals() {
        val filtered = if (currentFilter == "all") {
            allMeals
        } else {
            allMeals.filter { it.category == currentFilter }
        }
        mealAdapter.setMeals(filtered)
    }

    private fun addToCart(meal: Meal) {
        val existingItem = cart.find { it.id == meal.id }
        if (existingItem != null) {
            existingItem.quantity++
        } else {
            cart.add(CartItem(meal.id, meal.name, meal.price, 1))
        }
        Toast.makeText(this, "${meal.name} added to cart", Toast.LENGTH_SHORT).show()
    }

    private fun openCartDialog() {
        val dialog = Dialog(this)
        dialog.setContentView(R.layout.dialog_cart)
        dialog.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)

        val cartRecyclerView = dialog.findViewById<RecyclerView>(R.id.cartRecyclerView)
        val tvSubtotal = dialog.findViewById<TextView>(R.id.tvSubtotal)
        val tvTax = dialog.findViewById<TextView>(R.id.tvTax)
        val tvTotal = dialog.findViewById<TextView>(R.id.tvTotal)
        val btnCheckout = dialog.findViewById<Button>(R.id.btnCheckout)
        val btnClose = dialog.findViewById<Button>(R.id.btnClose)

        // Declare cartAdapter first
        lateinit var cartAdapter: CartAdapter

        // Then initialize it with the listener
        cartAdapter = CartAdapter(object : CartAdapter.OnCartActionListener {
            override fun onQuantityChanged(item: CartItem, newQuantity: Int) {
                item.quantity = newQuantity
                cartAdapter.setCartItems(cart)
                updateCartSummary(tvSubtotal, tvTax, tvTotal)
            }

            override fun onItemRemoved(item: CartItem) {
                cart.remove(item)
                cartAdapter.setCartItems(cart)
                updateCartSummary(tvSubtotal, tvTax, tvTotal)
            }
        })

        cartRecyclerView.layoutManager = LinearLayoutManager(this)
        cartRecyclerView.adapter = cartAdapter
        cartAdapter.setCartItems(cart)
        updateCartSummary(tvSubtotal, tvTax, tvTotal)

        btnCheckout.setOnClickListener {
            if (cart.isNotEmpty()) {
                val total = cart.sumOf { it.totalPrice }
                val tax = total * 0.08
                val finalTotal = total + tax
                Toast.makeText(this, "Order Complete! Total: $%.2f".format(finalTotal), Toast.LENGTH_LONG).show()
                cart.clear()
                dialog.dismiss()
            }
        }

        btnClose.setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    private fun updateCartSummary(tvSubtotal: TextView, tvTax: TextView, tvTotal: TextView) {
        val subtotal = cart.sumOf { it.totalPrice }
        val tax = subtotal * 0.08
        val total = subtotal + tax

        tvSubtotal.text = "$%.2f".format(subtotal)
        tvTax.text = "$%.2f".format(tax)
        tvTotal.text = "$%.2f".format(total)
    }
}