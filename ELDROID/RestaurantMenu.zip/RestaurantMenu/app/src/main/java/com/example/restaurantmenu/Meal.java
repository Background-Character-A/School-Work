package com.example.restaurantmenu;

public class Meal {
    private int id;
    private String name;
    private double price;
    private String category;
    private String image;
    private String description;

    public Meal(int id, String name, double price, String category, String image, String description) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.category = category;
        this.image = image;
        this.description = description;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public String getCategory() {
        return category;
    }

    public String getImage() {
        return image;
    }

    public String getDescription() {
        return description;
    }
}