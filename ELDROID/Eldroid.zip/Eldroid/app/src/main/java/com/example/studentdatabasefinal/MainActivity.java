package com.example.studentdatabasefinal;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.SearchView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.snackbar.Snackbar;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    StudentAdapter adapter;
    List<Student> studentList;
    DBHelper dbHelper;
    SearchView searchView;
    public static final int ADD_STUDENT_REQUEST = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        searchView = findViewById(R.id.searchView);

        // Initialize DB
        dbHelper = new DBHelper(this);
        studentList = dbHelper.getAllStudents();  // load all from DB

        // Set up adapter
        adapter = new StudentAdapter(this, studentList);
        recyclerView.setAdapter(adapter);

        // Search functionality
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                adapter.filterList(query);
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                adapter.filterList(newText);
                return true;
            }
        });

        // Enable drag & swipe
        enableDragAndSwipe();
    }

    private void enableDragAndSwipe() {
        ItemTouchHelper.SimpleCallback simpleCallback = new ItemTouchHelper.SimpleCallback(
                ItemTouchHelper.UP | ItemTouchHelper.DOWN, // drag directions
                ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT // swipe directions
        ) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView,
                                  @NonNull RecyclerView.ViewHolder viewHolder,
                                  @NonNull RecyclerView.ViewHolder target) {
                int from = viewHolder.getAdapterPosition();
                int to = target.getAdapterPosition();

                // Swap items
                List<Student> list = adapter.getStudentList();
                Student movedStudent = list.get(from);
                list.remove(from);
                list.add(to, movedStudent);

                adapter.notifyItemMoved(from, to);
                return true;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                int position = viewHolder.getAdapterPosition();
                Student deletedStudent = adapter.getStudentList().get(position);

                // Delete from DB
                dbHelper.deleteStudent(deletedStudent.getId());

                // Remove from both lists
                adapter.getStudentList().remove(position);
                adapter.getAllStudents().remove(deletedStudent);
                adapter.notifyItemRemoved(position);

                // Undo with Snackbar
                Snackbar.make(recyclerView, "Deleted " + deletedStudent.getName(), Snackbar.LENGTH_LONG)
                        .setAction("UNDO", v -> {
                            dbHelper.addStudent(deletedStudent);
                            adapter.getStudentList().add(position, deletedStudent);
                            adapter.getAllStudents().add(position, deletedStudent);
                            adapter.notifyItemInserted(position);
                        }).show();
            }

            @Override
            public boolean isLongPressDragEnabled() {
                return true; // allow drag
            }

            @Override
            public boolean isItemViewSwipeEnabled() {
                return true; // allow swipe
            }
        };

        new ItemTouchHelper(simpleCallback).attachToRecyclerView(recyclerView);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.option_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.add) {
            Intent intent = new Intent(this, AddMenu.class);
            startActivityForResult(intent, ADD_STUDENT_REQUEST);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK &&
                (requestCode == ADD_STUDENT_REQUEST || requestCode == StudentAdapter.EDIT_STUDENT_REQUEST)) {
            refreshStudentList();
        }
    }

    private void refreshStudentList() {
        List<Student> updatedList = dbHelper.getAllStudents();
        adapter.refreshData(updatedList);
    }
}
